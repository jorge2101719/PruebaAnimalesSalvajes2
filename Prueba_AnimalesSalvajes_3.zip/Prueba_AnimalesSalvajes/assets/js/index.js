import {Leon, Lobo, Oso, Serpiente, Aguila} from './animal.js';
import dato_animal from './api.js'

// ------------------------------------------------------

let animales = [];
let img = document.getElementById('preview');
let audio = document.getElementById('player');
let registrar = document.getElementById('btnRegistrar');
let nombre = document.getElementById('animal');
let imgLeon = `<img src="../assets/imgs/Leon.png" alt="León">`;
let imgLobo = `<img src="../assets/imgs/Lobo.jpg" alt="Lobo">`
let imgOso = `<img src="../assets/imgs/Oso.jpg" alt="Oso">`
let imgSerpiente = `<img src="../assets/imgs/Serpiente.jpg" alt="Serpiente">`;
let imgAguila = `<img src="../assets/imgs/Aguila.png" alt="Águila">`


registrar.addEventListener('click', async () => {
    let edad = document.getElementById('edad');
    let comentarios = document.getElementById('comentarios');
    let animal;

    if(nombre.value && edad.value && comentarios.value){
        let datos = await dato_animal.mostrar;

        if (nombre.value == "Leon") {
            animal = new Leon(
                nombre.value,
                edad.value,
                datos.animales[0].imagen,
                comentarios.value,
                datos.animales[0].sonido
            ); 
          } else if (nombre.value == "Lobo") {
            animal = new Lobo(
                nombre.value,
                edad.value,
                datos.animales[1].imagen,
                comentarios.value,
                datos.animales[1].sonido
            );
          } else if (nombre.value == "Oso") {
            animal = new Oso(
                nombre.value,
                edad.value,
                datos.animales[2].imagen,
                comentarios.value,
                datos.animales[2].sonido
            );
          } else if (nombre.value == "Serpiente") {
            animal = new Serpiente(
                nombre.value,
                edad.value,
                datos.animales[3].imagen,
                comentarios.value,
                datos.animales[3].sonido
            );
          } else if (nombre.value == "Aguila") {
            animal = new Aguila(
                nombre.value,
                edad.value,
                datos.animales[4].imagen,
                comentarios.value,
                datos.animales[4].sonido
            );
        }

        animales.push(animal);
        //nombre.selectedIndex = 0;
        //edad.selectedIndex = 0;
        //comentarios.value = "";
        //img.innerHTML = `<img src="">`;
        //animales.push(animal);
        limpiarDatos();
        agregarEnTabla();
    } else {
        alert(`Debe completar los datos en los tres campos`);
    }
});

const limpiarDatos = () =>{
    nombre.selectedIndex = 0;
    edad.selectedIndex = 0;
    comentarios.value = "";
    img.innerHTML = `<img src="">`;
};

document.getElementById('animal').addEventListener('change', function () {
    let nombre =document.getElementById('animal');
    if(nombre.value == 'Leon'){
        img.innerHTML = imgLeon;
    } else if(nombre.value == 'Lobo'){
        img.innerHTML = imgLobo;
    } else if(nombre.value == 'Oso'){
        img.innerHTML = imgOso;
    } else if(nombre.value == 'Serpiente'){
        img.innerHTML = imgSerpiente;
    } else if(nombre.value == 'Aguila'){
        img.innerHTML = imgAguila;
    }
});

let agregarEnTabla = () => {
    let animalesTemplate = document.getElementById("Animales");
    animalesTemplate.innerHTML = "";

    animales.forEach((animal, index) => {
    animalesTemplate.innerHTML += `
        <div class="m-2 col-2 card p-0">
            <div data-fighter="${animal.getNombre()}">
                <div>
                    <div>
                        <div>
                            <img src="../assets/imgs/${animal.getImg()}" alt="imagen_animal"
                            style="width: 100%; height: 100px"
                            onclick="verDatos(${index})"
                            data-toggle="modal"
                            data-target="#datos">
                        </div>
                        <div class="py-3 px-4 bg-dark">
                            <div class="m-1" id="audio" style="width: 40px; height: 40px; content-align: center" onclick="sonido(${index})">
                                <img src="../assets/imgs/audio.svg">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>`
    })
};

window.sonido = (entry) => {
    let animal = animales[entry];
    let sonido = animal.getSonido();
    audio.src = `../assets/sounds/${sonido}`;
    audio.play();
}

window.verDatos = (entry) => {
    let datos = animales[entry];
    let modal = document.getElementsByClassName('modal-body');
    //var myModal = new bootstrap.Modal(document.getElementsByClassName('modal-body'), { focus: datos.Comentarios() } );
    //let modal = document.getElementById('datosAnimal');
    modal.innerHTML =
        `<div class="p-0" style="position: absolute; width: 300px; heigth: 400px">
            <div class="modal-header">
                <img src="../assets/imgs/${datos.getImg()}" style="width: 200px">
            </div class="text-center mt-2">
            <div class="modal-body">
                <p class="text-white">Edad: ${datos.getEdad()}</p>
            </div>
            <div class="text-center mt-2 text-white modal-footer">
                <p>Comentarios</p>
                <p>${datos.getComentarios()}</p>
            </div>
        </div>`;
    console.log(datos.getImg() + ' ' + datos.getEdad() + ' ' + datos.getComentarios());
}

console.log(animales);

$(document).ready(function verDatos(entry) {
    let animal = animales[entry];
    console.log(animales[entry]);
    let modal = $('.modal-body');
    modal.innerHTML =
    `<div class="p-0" style="position: absolute; width: 300px; heigth: 400px">
        <div class="modal-header">
            <img src="../assets/imgs/${animal.getImg()}" style="width: 200px">
        </div class="text-center mt-2">
        <div class="modal-body">
            <p class="text-white">Edad: ${animal.getEdad()}</p>
        </div>
        <div class="text-center mt-2 text-white modal-footer">
            <p>Comentarios</p>
            <p>${animal.getComentarios()}</p>
        </div>
    </div>`;
console.log(animal.getImg() + ' ' + animal.getEdad() + ' ' + animal.getComentarios());
})
