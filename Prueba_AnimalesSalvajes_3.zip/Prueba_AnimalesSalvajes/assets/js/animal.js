export class Animal {
    constructor(nombre, edad, img, comentarios, sonido){
        let Nombre = nombre;
        this.getNombre = () => Nombre

        let Edad = edad;
        this.getEdad = () => Edad;

        let Img =img;
        this.getImg = () => Img;

        let Comentarios = comentarios;
        this.getComentarios = () => Comentarios;
        //let Comentarios = comentarios;
        //this.setComentarios = (nuevo_comentario) => Comentarios = nuevo_comentario;

        let Sonido = sonido;
        this.getSonido = () => Sonido;
    }

    get Nombre() {
        return this._getNombre;
    }

    get Edad() {
        return this._getEdad;
    }

    get Img() {
        return this._getImg;
    }

    get Sonido() {
        return this._getSonido;
    }

    set Comentarios (nuevo_comentario){
        this._getComentarios = nuevo_comentario;
    }
}

export class Leon extends Animal {
    constructor(nombre, edad, img, comentarios, sonido) {
        super(nombre, edad, img, comentarios, sonido);
    }

    rugir(){
        return this.sonido;
    }
}

export class Lobo extends Animal {
    constructor(nombre, edad, img, comentarios, sonido) {
        super(nombre, edad, img, comentarios, sonido);
    }

    aullar(){
        return this.sonido;
    }
}

export class Oso extends Animal {
    constructor(nombre, edad, img, comentarios, sonido) {
        super(nombre, edad, img, comentarios, sonido);
    }

    grunir(){
        return this.sonido;
    }
}

export class Serpiente extends Animal {
    constructor(nombre, edad, img, comentarios, sonido) {
        super(nombre, edad, img, comentarios, sonido);
    }

    sisear(){
        return this.sonido;
    }
}

export class Aguila extends Animal {
    constructor(nombre, edad, img, comentarios, sonido) {
        super(nombre, edad, img, comentarios, sonido);
    }

    chillar(){
        return this.sonido;
    }
}